import vue_flood
import modele_flood

class controle:

    def __init__(self) -> None:
        
        self.__modele = modele_flood.Modele()
        self.__vue = vue_flood.Vue(self.__modele, self)


    def creer_controleur_bouton(self, l, c):
        def controleur_btn()->None:
            self.__modele.choisit_couleur(self.__modele.val_coul(l,c))
            self.__vue.redessine()
            self.finie()
        return controleur_btn



    def demarre(self):
        self.__vue.demarre()

    def finie(self):
        if self.__modele.partie_finie():
            self.__vue.partie_finie()

    def nouvelle_partie(self):
        self.__modele.reinit_jeu()
