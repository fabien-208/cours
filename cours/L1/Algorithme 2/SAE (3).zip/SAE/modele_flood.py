import random
class Modele:

    def __init__(self, nb_colonne:int = 12, nb_lignes:int = 12, coul:int = 6) -> None:
        """
        >>> mod = Modele()
        >>> mod.nb_lig()
        12
        >>> mod.nb_col()
        12
        >>> mod.nb_coul()
        6
        >>> print(mod)
        | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10| 11|
        ----------------------------------------------------
        0| 1 | 1 | 0 | 2 | 4 | 0 | 0 | 2 | 0 | 3 | 3 | 0 |
        ----------------------------------------------------
        1| 5 | 1 | 0 | 5 | 2 | 5 | 1 | 3 | 5 | 1 | 4 | 3 |
        ----------------------------------------------------
        2| 1 | 2 | 5 | 4 | 5 | 1 | 5 | 2 | 2 | 4 | 1 | 1 |
        ----------------------------------------------------
        3| 2 | 2 | 0 | 1 | 2 | 4 | 3 | 4 | 0 | 0 | 1 | 0 |
        ----------------------------------------------------
        4| 3 | 0 | 0 | 3 | 3 | 3 | 2 | 0 | 1 | 4 | 4 | 0 |
        ----------------------------------------------------
        5| 5 | 5 | 1 | 5 | 4 | 0 | 4 | 3 | 5 | 5 | 0 | 5 |
        ----------------------------------------------------
        6| 0 | 5 | 4 | 2 | 4 | 5 | 5 | 5 | 0 | 4 | 1 | 3 |
        ----------------------------------------------------
        7| 2 | 0 | 5 | 0 | 1 | 0 | 3 | 5 | 3 | 2 | 2 | 2 |
        ----------------------------------------------------
        8| 4 | 4 | 1 | 2 | 0 | 2 | 5 | 3 | 3 | 2 | 5 | 0 |
        ----------------------------------------------------
        9| 5 | 4 | 4 | 3 | 3 | 2 | 0 | 1 | 2 | 5 | 1 | 2 |
        ----------------------------------------------------
        10| 3 | 4 | 1 | 4 | 3 | 5 | 3 | 0 | 4 | 1 | 4 | 0 |
        ----------------------------------------------------
        11| 2 | 5 | 3 | 2 | 1 | 2 | 1 | 0 | 4 | 2 | 4 | 4 |
        ----------------------------------------------------
        >>> mod.valeur_couleur(0,9)
        3
        >>> mod.valeur_couleur(0,0)
        1
        >>> mod.choisit_couleur(0,9)
        >>> mod.valeur_couleur(0,0)
        3
        """
        self.__nb_colonne = nb_colonne
        self.__nb_ligne = nb_lignes
        self.__coul = coul
        self.__score = 0
        self.__terminé = False
        self.__jeu = []
        for i in range(self.__nb_colonne):
            lig = []
            for j in range(self.__nb_ligne):
                lig.append(Case(random.randint(0, self.__coul-1),False,(i, j),self)) 
            self.__jeu.append(lig)

    
    
    def score(self):
        return self.__score
    
    def nb_lig(self) -> int:
        return self.__nb_ligne
    
    def nb_col(self) -> int:
        return self.__nb_colonne
    
    def nb_coul(self) -> int:
        return self.__coul

    def valeur_couleur(self, l:int, c:int) -> int:
        return self.__jeu[l][c].coul()
    

    def choisit_couleur(self,coul) -> None:
        self.__jeu[0][0].changer_coul(coul)

    def voisines(self, l, c):
        return self.__jeu[l][c].voisine()


    def reinit_jeu(self):
        self.__score = 0
        self.__terminé = False
        self.__jeu = []
        for i in range(self.__nb_colonne):
            lig = []
            for j in range(self.__nb_ligne):
                lig.append(Case(random.randint(0, self.__coul-1),False,(i, j),self)) 
            self.__jeu.append(lig)


    def __str__(self) -> str:
        plateau = ' |'
        for i in range(self.__nb_colonne):
            plateau += (' {} |'.format(i))
        plateau += '\n'
        for l in range(self.__nb_ligne):
            for j in range(self.__nb_ligne):
                plateau += '----'
            plateau += '\n'
            plateau += ('{}'.format(l))
            for k in range(self.__nb_colonne):
                plateau+= ('| {} '.format(self.__jeu[l][k]))
            plateau += '\n'
        return plateau
    
    def pose_couleur(self, cou, i, j):
        self.calcul_czse_touché()
        self.__jeu[0][0].changer_coul(cou)
        for i in self.__jeu:
            for j in i:
                if j.__touché == True:
                    j.changer_coul(cou)
        self.partie_finie()
        


    def calcul_czse_touché(self):
            lis=[]
            verifier=[(0,0)]
            for i in range(len(self.voisines(0,0))):
                if self.__jeu[i[0]][i[1]].coul() == self.__jeu[0][0].coul():
                    self.__jeu[i[0]][i[1]].touché()
                    for j in self.voisines(i[0],i[1]):
                        if not(j in lis) and not(j in verifier):
                            lis.append(j)
                verifier.append(self.__jeu[i[0]][i[1]].coord())

            while len(lis) != 0:
                jrf = 0
                for i in range(len(lis)):
                    if self.__jeu[lis[0][0]][lis[0][1]].coul() == self.__jeu[0][0].coul():
                        self.__jeu[lis[0][0]][lis[0][1]].touché()
                        verifier.append(self.__jeu[lis[0][0]][lis[0][1]].coord())
                        for j in self.voisines(lis[0][0],lis[0][1]):
                            if not(j in lis) and not(j in verifier):
                                lis.append(j)
                    else:
                        verifier.append(self.__jeu[lis[0][0]][lis[0][1]].coord())
                    lis.pop(0)
                    jrf += 1
    



    def partie_finie(self):
        coul = self.__jeu[0][0].coul()
        for i in range(self.nb_lig()):
            for j in range(self.nb_col()):
                if self.__jeu[i][j].coul() != coul:
                    self.__terminé = False
        self.__terminé = True

    def val_coul(self, l, c):
        return self.__jeu[l][c].coul()



class Case:

    def __init__(self, couleur:int, touché:bool, coordonnées:tuple, Modele) -> None:
        self.__couleur  = couleur
        self.__coord = coordonnées
        self.__touché = touché
        self.__taille = [Modele.nb_lig(), Modele.nb_col()]
                


    def coul(self):
        return self.__couleur

    def coord(self):
        return self.__coord

    def val_touché(self):
        return self.__touché    

    def voisine(self):
        if self.__coord[0] == 0 and self.__coord[1] == 0:
            return [(0, 1), (1, 0)]
        
        if self.__coord[0] == 0 and self.__coord[1] == self.__taille[0]-1:
            return [(0, self.__taille[0]-2), (1, self.__taille[1]-1)]
        
        if self.__coord[0] == self.__taille[0]-1 and self.__coord == 0:
            return [(self.__taille[0]-2, 0), (self.__taille[0]-1, 1)]
         
        if self.__coord[0] == self.__taille[1]-1 and self.__coord[1] == self.__taille[0]-1:
            return [(self.__taille[1]-1, self.__taille[0]-2), (self.__taille[1]-2, self.__taille[0]-1)]
        
        if self.__coord[0] == 0:
            return [(0,self.__coord[1]+1),(0,self.__coord[1]-1),(1,self.__coord[1])]
        
        if self.__coord[0] == self.__taille[1]-1:
            return [(self.__taille[1]-1,self.__coord[1]-1),(self.__taille[1]-1,self.__coord[1]+1),(self.__taille[1]-2,self.__coord[1])]
        
        if self.__coord[1] == 0:
            return [(self.__coord[0],1),(self.__coord[0]-1,0),(self.__coord[0]+1,0)]
        
        if self.__coord[1] == self.__taille[0]-1:
            return [(self.__coord[0]-1,self.__coord[1]),(self.__coord[0]+1,self.__coord[1]),(self.__coord[0],self.__coord[1]-1)]

        else:
            return [(self.__coord[0]-1,self.__coord[1]),(self.__coord[0]+1,self.__coord[1]),(self.__coord[0],self.__coord[1]+1),(self.__coord[0],self.__coord[1]-1)]




    def changer_coul(self, coul:int):
        self.__couleur = coul

    def touché(self):
        self.__touché =True




if '__main__' == __name__:
    import doctest
    doctest.testmod(verbose=True)