import Cntrl_Flood

if __name__ == "__main__":
    Cntrl_Flood.floodcontroleur().demarre()

