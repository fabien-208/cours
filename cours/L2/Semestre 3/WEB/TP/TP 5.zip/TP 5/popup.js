window.onload = function() {
    alert(document.title);
};
